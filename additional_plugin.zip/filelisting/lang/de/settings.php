<?php
/**
 * english language file for filelisting plugin
 *
 * @author Szymon Olewniczak <dokuwiki@cosmocode.de>
 */

$lang['defaulttoggle'] = 'Zeige Dateiauflistung standardmäßig an';
$lang['remember_state_per_page'] = 'Wie wird der Zustand der Dateiauflistung gespeichert?';
$lang['remember_state_per_page_o_page'] = 'seitenweise (sinnvoll wenn die Syntax des Plugins genutzt wird)';
$lang['remember_state_per_page_o_wiki'] = 'seitenübergreifend (sinnvoll wenn das Plugin Teil des Wikitemplates ist)';



//Setup VIM: ex: et ts=4 :
