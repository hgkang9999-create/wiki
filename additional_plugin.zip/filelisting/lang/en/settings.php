<?php
/**
 * english language file for filelisting plugin
 *
 * @author Szymon Olewniczak <dokuwiki@cosmocode.de>
 */

$lang['defaulttoggle'] = 'Expanded listings by default';
$lang['remember_state_per_page'] = 'How to remember the state of the listing';
$lang['remember_state_per_page_o_page'] = 'per page (makes sense if plugin is used as syntax)';
$lang['remember_state_per_page_o_wiki'] = 'cross-page (makes sense if plugin is used as part of the wiki template)';



//Setup VIM: ex: et ts=4 :
