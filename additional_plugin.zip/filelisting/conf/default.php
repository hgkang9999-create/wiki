<?php
/**
 * Default settings for the filelisting plugin
 *
 * @author Szymon Olewniczak <dokuwiki@cosmocode.de>
 */

$conf['defaulttoggle']    = '1';
$conf['remember_state_per_page'] = 'page';
