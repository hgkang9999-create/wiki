<?php
/**
 * Options for the filelisting plugin
 *
 * @author Szymon Olewniczak <dokuwiki@cosmocode.de>
 */


$meta['defaulttoggle'] = array('onoff');
$meta['remember_state_per_page'] = array('multichoice','_choices' => array('page','wiki'));
