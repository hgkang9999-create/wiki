<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Aleksandr Selivanov <alexgearbox@yandex.ru>
 */
$lang['page']                  = 'Страница';
$lang['date']                  = 'Дата';
$lang['user']                  = 'Участник';
$lang['desc']                  = 'Описание';
$lang['diff']                  = 'Отличия';
$lang['summary']               = 'Сводка изменений';
$lang['diff_title']            = 'Показать отличия от текущей версии';
$lang['diff_alt']              = 'Показать отличия от текущей версии';
