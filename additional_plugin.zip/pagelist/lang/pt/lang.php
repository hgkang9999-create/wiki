<?php

/**
 * Portuguese language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Daniel Dias Rodrigues <danieldiasr@gmail.com>
 * @author Fernando Ribeiro <pinguim.ribeiro@gmail.com>
 */
$lang['page']                  = 'Página';
$lang['date']                  = 'Data';
$lang['user']                  = 'Utilizador';
$lang['desc']                  = 'Descrição';
$lang['diff']                  = 'Diferenças';
$lang['diff_title']            = 'Mostrar diferenças para as revisões atuais';
$lang['diff_alt']              = 'Mostrar diferenças para as revisões atuais';
