<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Schplurtz le Déboulonné <schplurtz@laposte.net>
 * @author Olivier Humbert <trebmuh@tuxfamily.org>
 * @author Laynee <seedfloyd@gmail.com>
 */
$lang['page']                  = 'Page';
$lang['date']                  = 'Date';
$lang['user']                  = 'Utilisateur';
$lang['desc']                  = 'Description';
$lang['diff']                  = 'Différences';
$lang['summary']               = 'Résumé d\'édition';
$lang['diff_title']            = 'Différences avec la version précédente';
$lang['diff_alt']              = 'Différences avec la version précédente';
