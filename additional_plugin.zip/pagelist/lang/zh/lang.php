<?php

/**
 * Simplified Chinese language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author techbox <tech-box@outlook.com>
 * @author haobug <qingxianhao@gmail.com>
 */
$lang['page']                  = '页面';
$lang['date']                  = '日期';
$lang['user']                  = '用户';
$lang['desc']                  = '描述';
$lang['diff']                  = '差异';
$lang['diff_title']            = '显示与当前修订版的差异';
$lang['diff_alt']              = '显示与当前修订版的差异';
