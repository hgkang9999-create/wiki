<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Tor Härnqvist <tor@harnqvist.se>
 */
$lang['page']                  = 'Sida';
$lang['date']                  = 'Datum';
$lang['user']                  = 'Användare';
$lang['desc']                  = 'Beskrivning';
$lang['diff']                  = 'Skillnader';
$lang['diff_title']            = 'Visa skillnader mot nuvarande version';
$lang['diff_alt']              = 'Visa skillnader mot nuvarande version';
