<?php
/**
 * Esperanta dosiero
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Felipe Castro <fefcas@yahoo.com.br>
 */

// persona lingvo-cxenoj por la ilero (plugin)
$lang['page'] = 'Paĝo';
$lang['date'] = 'Dato';
$lang['user'] = 'Uzulo';
$lang['desc'] = 'Priskribo';

//Setup VIM: ex: et ts=2 enc=utf-8 :
