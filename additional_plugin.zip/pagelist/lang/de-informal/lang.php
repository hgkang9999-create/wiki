<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author F. Mueller-Donath <j.felix@mueller-donath.de>
 */
$lang['page']                  = 'Seite';
$lang['date']                  = 'Datum';
$lang['user']                  = 'Benutzer';
$lang['desc']                  = 'Beschreibung';
$lang['diff']                  = 'Unterschiede';
$lang['diff_title']            = 'Zeige Unterschiede zur aktuellen Version';
$lang['diff_alt']              = 'Zeige Unterschiede zur aktuellen Version';
