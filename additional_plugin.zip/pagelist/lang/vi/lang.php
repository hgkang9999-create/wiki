<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Minh <phandinhminh@protonmail.ch>
 */
$lang['page']                  = 'Trang';
$lang['date']                  = 'Ngày tháng';
$lang['user']                  = 'Người dùng';
$lang['desc']                  = 'Mô tả';
$lang['diff']                  = 'Khác biệt';
$lang['diff_title']            = 'Hiện các khác biệt với các sửa đổi hiện thời';
$lang['diff_alt']              = 'Hiện các khác biệt với các sửa đổi hiện thời';
