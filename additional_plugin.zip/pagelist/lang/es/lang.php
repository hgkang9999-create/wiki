<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Herman Fabián Sandoval Manrique <hfsandovalm@emzac.com>
 * @author Domingo Redal <docxml@gmail.com>
 */
$lang['page']                  = 'Página';
$lang['date']                  = 'Fecha';
$lang['user']                  = 'Usuario';
$lang['desc']                  = 'Descripción';
$lang['diff']                  = 'Diferencias';
$lang['diff_title']            = 'Mostrar diferencias con la revisión actual';
$lang['diff_alt']              = 'Mostrar diferencias con la revisión actual';
