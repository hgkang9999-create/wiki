<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author DelD <deldadam@gmail.com>
 */
$lang['page']                  = 'Oldal';
$lang['date']                  = 'Dátum';
$lang['user']                  = 'Felhasználó';
$lang['desc']                  = 'Leírás';
$lang['diff']                  = 'Eltérések';
$lang['diff_title']            = 'Aktuális revizíóhoz képesti eltérések kijelzése';
$lang['diff_alt']              = 'Aktuális revizíóhoz képesti eltérések kijelzése';
