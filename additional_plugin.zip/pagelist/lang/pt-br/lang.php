<?php

/**
 * 
 * Arquivo para o português
 * 
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Daniel Dias Rodrigues <danieldiasr@gmail.com>
 * @author Gilson Caldeira <gilsoncaldeira@gmail.com>
 * @author Sidnei Neves <sidnei@sidnei.org>
 */
$lang['page']                  = 'Página';
$lang['date']                  = 'Data';
$lang['user']                  = 'Usuário';
$lang['desc']                  = 'Descrição';
$lang['diff']                  = 'Diferenças';
$lang['summary']               = 'Editar sumário';
$lang['diff_title']            = 'Mostrar diferenças para as revisões atuais';
$lang['diff_alt']              = 'Mostrar diferenças para as revisões atuais';
