<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Arne Hanssen <arne.hanssen@getmail.no>
 */
$lang['page']                  = 'Side';
$lang['date']                  = 'Dato';
$lang['user']                  = 'Bruker';
$lang['desc']                  = 'Beskrivelse';
$lang['diff']                  = 'Forskjeller';
$lang['diff_title']            = 'Vis forskjeller til nåværende versjoner';
$lang['diff_alt']              = 'Vis forskjeller til nåværende versjoner';
