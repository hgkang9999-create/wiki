<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author S.C.Yoo <dryoo@live.com>
 * @author Myeongjin <aranet100@gmail.com>
 * @author Erial <erial2@gmail.com>
 */
$lang['page']                  = '문서';
$lang['date']                  = '날짜';
$lang['user']                  = '사용자';
$lang['desc']                  = '설명';
$lang['diff']                  = '차이';
$lang['diff_title']            = '현재 판과의 차이 보기';
$lang['diff_alt']              = '현재 판과의 차이 보기';
