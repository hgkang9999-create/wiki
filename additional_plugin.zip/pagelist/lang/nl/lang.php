<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Gerrit <klapinklapin@gmail.com>
 * @author Esther Brunner <wikidesign@gmail.com>
 * @author Mark C. Prins <mprins@users.sf.net>
 * @author Hugo Smet <hugo.smet@scarlet.be>
 */
$lang['page']                  = 'Pagina';
$lang['date']                  = 'Datum';
$lang['user']                  = 'Gebruiker';
$lang['desc']                  = 'Beschrijving';
$lang['diff']                  = 'Verschillen';
$lang['summary']               = 'Bewerkingssamenvatting ';
$lang['diff_title']            = 'Toon verschillen met de huidige revisies';
$lang['diff_alt']              = 'Toon verschillen met de huidige revisies';
