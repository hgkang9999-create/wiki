<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Jacob Palm <jacobpalmdk@icloud.com>
 */
$lang['page']                  = 'Side';
$lang['date']                  = 'Dato';
$lang['user']                  = 'Bruger';
$lang['desc']                  = 'Beskrivelse';
$lang['diff']                  = 'Forskelle';
$lang['diff_title']            = 'Vis forskelle fra nuværende revisioner';
$lang['diff_alt']              = 'Vis forskelle fra nuværende revisioner';
