<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author andreash <aeheil@gmail.com>
 * @author Esther Brunner <wikidesign@gmail.com>
 * @author Dominik Eckelmann <deckelmann@gmail.com>
 * @author e-dschungel <github@e-dschungel.de>
 */
$lang['page']                  = 'Seite';
$lang['date']                  = 'Datum';
$lang['user']                  = 'Benutzer';
$lang['desc']                  = 'Beschreibung';
$lang['diff']                  = 'Unterschiede';
$lang['summary']               = 'Zusammenfassung bearbeiten';
$lang['diff_title']            = 'Zeige Unterschiede zur aktuellen Version';
$lang['diff_alt']              = 'Zeige Unterschiede zur aktuellen Version';
