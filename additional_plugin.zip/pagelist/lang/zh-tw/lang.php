<?php
/**
 * Traditional Chinese language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Danny Lin <danny0838@gmail.com>
 */

// custom language strings for the plugin
$lang['page'] = '頁面';
$lang['date'] = '日期';
$lang['user'] = '使用者';
$lang['desc'] = '描述';

//Setup VIM: ex: et ts=2 enc=utf-8 :