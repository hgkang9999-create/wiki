<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Alan Davies <ben.brynsadler@gmail.com>
 */
$lang['page']                  = 'Tudalen';
$lang['date']                  = 'Dyddiad';
$lang['user']                  = 'Defnyddiwr';
$lang['desc']                  = 'Disgrifiad';
$lang['diff']                  = 'Gwahaniaethau';
$lang['diff_title']            = 'Dangos gwahaniaethau i adolygiadau cyfredol';
$lang['diff_alt']              = 'Dangos gwahaniaethau i adolygiadau cyfredol';
