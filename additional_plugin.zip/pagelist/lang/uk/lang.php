<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Олексій <alexey.furashev@gmail.com>
 */
$lang['page']                  = 'Сторінка';
$lang['date']                  = 'Дата';
$lang['user']                  = 'Користувач';
$lang['desc']                  = 'Опис';
$lang['diff']                  = 'Відмінності';
$lang['diff_title']            = 'Показати відмінності від поточних змін';
$lang['diff_alt']              = 'Показати відмінності від поточних змін';
