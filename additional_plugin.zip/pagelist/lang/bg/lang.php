<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Kiril <neohidra@gmail.com>
 */
$lang['page']                  = 'Страница';
$lang['date']                  = 'Дата';
$lang['user']                  = 'Потребител';
$lang['desc']                  = 'Описание';
$lang['diff']                  = 'Разлики';
$lang['diff_title']            = 'Покажи разликите с текущата версия';
$lang['diff_alt']              = 'Покажи разликите с текущата версия';
