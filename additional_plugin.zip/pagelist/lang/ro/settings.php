<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Mircea Simion <mircea.simion@gmail.com>
 */
$lang['style_o_default']       = 'implicit';
$lang['style_o_table']         = 'tabel';
$lang['style_o_list']          = 'tabel/lista';
$lang['style_o_simple']        = 'lista simpla';
$lang['showdate_o_0']          = 'ascunde';
$lang['showuser_o_0']          = 'ascunde';
