<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Mircea Simion <mircea.simion@gmail.com>
 */
$lang['page']                  = 'Pagina';
$lang['date']                  = 'Data';
$lang['user']                  = 'Utilizator';
$lang['desc']                  = 'Descriere';
$lang['diff']                  = 'Diferente';
