<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Roberto Bellingeri <bellingeri@netguru.it>
 * @author Willy <willygroup@gmail.com>
 * @author OlatusRooc <olatusrooc@virgilio.it>
 * @author Marco Fenoglio <marco.fenoglio@gmail.com>
 */
$lang['page']                  = 'Pagina';
$lang['date']                  = 'Data';
$lang['user']                  = 'Utente';
$lang['desc']                  = 'Descrizione';
$lang['diff']                  = 'Differenze';
$lang['diff_title']            = 'Mostra le differenze alle revisioni correnti';
$lang['diff_alt']              = 'Mostra le differenze alle revisioni correnti';
