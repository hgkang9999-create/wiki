<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Michał <kamykowsky@gmail.com>
 */
$lang['page']                  = 'Strona';
$lang['date']                  = 'Data';
$lang['user']                  = 'Użytkownik';
$lang['desc']                  = 'Opis';
$lang['diff']                  = 'Różnice';
$lang['summary']               = 'Edytuj podsumowanie';
$lang['diff_title']            = 'Pokaż różnice w stosunku do aktualnej wersji';
$lang['diff_alt']              = 'Pokaż różnice w stosunku do aktualnej wersji';
