<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Esther Brunner <wikidesign@gmail.com>
 * @author İlker R. Kapaç <irifat@gmail.com>
 */
$lang['page']                  = 'Sayfa';
$lang['date']                  = 'Tarih';
$lang['user']                  = 'Kullanıcı';
$lang['desc']                  = 'Açıklama';
$lang['diff']                  = 'Farklar';
$lang['diff_title']            = 'Güncel sürümler ile aradaki farkları göster';
$lang['diff_alt']              = 'Güncel sürümler ile aradaki farkları göster';
