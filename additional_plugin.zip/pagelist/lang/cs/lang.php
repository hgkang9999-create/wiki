<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Lukas Zapletal <lukas.zapletal at gmail dot com>
 * @author Roman Svoboda <svoboro1@fel.cvut.cz>
 */
$lang['page']                  = 'Stránka';
$lang['date']                  = 'Datum';
$lang['user']                  = 'Uživatel';
$lang['desc']                  = 'Popis';
$lang['diff']                  = 'Rozdíly';
$lang['diff_title']            = 'Zobrazit rozdíly vůči aktuální verzi';
$lang['diff_alt']              = 'Zobrazit rozdíly vůči aktuální verzi';
