<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author qezwan <qezwan@gmail.com>
 */
$lang['page']                  = 'پەڕە';
$lang['date']                  = 'بەروار';
$lang['user']                  = 'بەکارهێنەر';
$lang['desc']                  = 'وەسف';
$lang['diff']                  = 'جیاوازیەکان';
$lang['diff_title']            = 'جیاوازیەکان نیشان بدە بۆ پێداچوونەوەکانی ئێستا';
$lang['diff_alt']              = 'جیاوازیەکان نیشان بدە بۆ پێداچوونەوەکانی ئێستا';
