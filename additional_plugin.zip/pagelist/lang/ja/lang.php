<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Ikuo Obataya <cxx05051@nifty.com>
 * @author Hideaki SAWADA <chuno@live.jp>
 */
$lang['page']                  = 'ページ';
$lang['date']                  = '日付';
$lang['user']                  = 'ユーザー';
$lang['desc']                  = '内容';
$lang['diff']                  = '差分';
$lang['diff_title']            = '現在のリビジョンとの差分を表示';
$lang['diff_alt']              = '現在のリビジョンとの差分を表示';
