<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Rene <wllywlnt@yahoo.com>
 */
$lang['menu']                  = 'Automatische Uitlog Configuratie';
$lang['loggedoff']             = '%s werd automatisch uitgelogd';
$lang['usergroup']             = 'Gebruiker/Groep';
$lang['time']                  = 'Tijd (min)';
$lang['save']                  = 'Voeg toe';
$lang['mintime']               = 'Ingestelde tijd moet minimaal 2 minuten bedragen of gebruik 0 om de auto uitlog uit te schakelen. De opgegeven tijd is aangepast.';
$lang['remove']                = 'verwijder';
$lang['js']['title']           = 'Automatische uitlog';
$lang['js']['warn']            = 'Je ben enige tijd inactief. Je wordt in een minuut automatisch uitgelogd.';
$lang['js']['stillhere']       = 'Nee, ik ben er nog!';
