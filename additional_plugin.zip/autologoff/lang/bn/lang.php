<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author ninetailz <ninetailz1125@gmail.com>
 */
$lang['menu']                  = 'স্বয়ংক্রিয় লগিন অফ কনফিগারেশন';
$lang['loggedoff']             = '%s স্বয়ংক্রিয়ভাবে বন্ধ দর্শন লগ করা হয়েছে';
$lang['usergroup']             = 'ব্যবহারকারী / গ্রুপ';
$lang['time']                  = 'সময় (কমপক্ষে)';
$lang['save']                  = 'এন্ট্রি যোগ করুন';
$lang['mintime']               = 'টাইমস অটো লগ আউট নিষ্ক্রিয় অন্তত 2 মিনিট বা 0 হতে হবে. নির্দিষ্ট সময় স্থায়ী করা হয়েছে.';
$lang['remove']                = 'অপসারণ';
$lang['js']['title']           = 'Automatic Log-Off';
$lang['js']['warn']            = 'আপনি কিছুদিনের জন্য নিষ্ক্রিয় চলেছি. আপনি স্বয়ংক্রিয়ভাবে সম্পর্কে একটি মিনিট বন্ধ বন্ধু হিসেবে যুক্ত করো.';
$lang['js']['stillhere']       = 'না, আমি এখানে এখনও আছি!';
