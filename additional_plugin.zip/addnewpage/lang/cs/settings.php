<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Martin Růžička <martinr@post.cz>
 * @author Jaroslav Lichtblau <jlichtblau@seznam.cz>
 */
$lang['addpage_exclude']       = 'Vyloučit jmenné prostory (oddělené středníkem ;)';
$lang['addpage_showroot']      = 'Zobrazit kořenový jmenný prostor';
$lang['addpage_hide']          = 'Pokud použijete syntaxi {{NEWPAGE>[ns]}}: Skrýt výběr jmenného prostoru (pokud není zaškrtnuto zobrazit pouze jmenné podprostory)';
$lang['addpage_hideACL']       = 'Skrýt {{NEWPAGE}} pokud uživatel nemá práva přidávat stránky (pokud není zaškrtnuto zobrazit zprávu)';
$lang['addpage_autopage']      = 'Nezobrazovat vstupní pole, předkonfigurovaný jmenný prostor je považován za úplné ID stránky (má smysl u zástupných symbolů data)';
