<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Martin Růžička <martinr@post.cz>
 * @author Jaroslav Lichtblau <jlichtblau@seznam.cz>
 */
$lang['namespaceRoot']         = 'Kořen';
$lang['name']                  = 'Název stránky';
$lang['okbutton']              = 'Přidat stránku';
$lang['nooption']              = 'Nejste oprávněni přidávat stránky';
