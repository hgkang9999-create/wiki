<?php

/**
 * @license    GPL 2 (https://www.gnu.org/licenses/gpl.html)
 *
 * Chinese(Simplified) language file
 *
 * @author 小命Leaflet <2532846822@qq.com>
 */
$lang['namespaceRoot']         = '根部命名空间';
$lang['name']                  = '页面名称';
$lang['okbutton']              = '增加页面';
$lang['nooption']              = '抱歉，您没有权限增加页面';
