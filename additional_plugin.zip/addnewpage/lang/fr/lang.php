<?php
/*USE : UTF8*/
/*
 * French language file
 */
$lang['namespaceRoot'] = "Racine";
$lang['name']          = "Nom de la page";
$lang['okbutton']      = "Créer";
$lang['nooption']      = "Vous n'avez pas les droits pour ajouter une page";
