<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author qezwan <qezwan@gmail.com>
 */
$lang['namespaceRoot']         = 'ڕەگ';
$lang['okbutton']              = 'زیادکردنی لاپەڕە';
$lang['nooption']              = 'تۆ ڕێگەت پێنەدراوە لاپەڕەزیاد بکەیت';
