<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author qezwan <qezwan@gmail.com>
 */
$lang['addpage_exclude']       = 'بۆشایی ناوی بەدەرکراو (جیاکراونەتەوە لەگەڵ ;)';
$lang['addpage_showroot']      = 'بۆشایی ناوی ڕەگ نیشان بدە';
$lang['addpage_hide']          = 'کاتێک تۆ {{NEWPAGE>[ns]}} ڕستەسازی بەکاردێنیت: شاردنەوەی دیاریکردنی بۆشایی ناو (نەپشکندراوە: تەنها ژێربۆشایی پیشان بدە)';
$lang['addpage_hideACL']       = 'شاردنەوە {{NEWPAGE}} ئەگەر بەکارهێنەر مافی ئەوەی نییە لاپەڕەزیاد بکات (نیشاندانی پەیام ئەگەر نەپشکنرابێت)';
