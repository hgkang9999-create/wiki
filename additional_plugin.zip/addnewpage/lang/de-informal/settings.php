<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author MaWi <drmaxxis@gmail.com>
 * @author Michael <michael.kraemer@gmail.com>
 */
$lang['addpage_exclude']       = 'Namespaces ausschließen (getrennt mit ; )';
$lang['addpage_showroot']      = 'Wurzel-Namespace anzeigen';
$lang['addpage_hide']          = '{{NEWPAGE>[ns]}} Syntax: Ausgewählt, diese Namespace-Auswahl verbergen. Nicht ausgewählt, nur diese Namespace-Auswahl anzeigen.';
$lang['addpage_hideACL']       = 'Verberge {{NEWPAGE}} wenn ein Benutzer keine Berechtigung hat Seiten hinzuzufügen
Ausgewählt: Anzeige wird verborgen
Nicht ausgewählt: es wird eine Fehlermeldung ausgegeben';
