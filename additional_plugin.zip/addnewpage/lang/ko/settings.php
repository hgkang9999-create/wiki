<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Myeongjin <aranet100@gmail.com>
 */
$lang['addpage_exclude']       = '제외할 이름공간 (;로 구분)';
$lang['addpage_showroot']      = '루트 이름공간 보이기';
$lang['addpage_hide']          = '{{NEWPAGE>[ns]}} 구문을 사용할 때: 이름공간 선택을 숨기기 (체크하지 않음: 하위 이름공간만 보이기)';
$lang['addpage_hideACL']       = '사용자가 문서를 추가할 권한이 없을 때 {{NEWPAGE}} 숨기기 (체크하지 않으면 메시지 보이기)';
