<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Arne Hanssen <arne.hanssen@getmail.no>
 */
$lang['namespaceRoot']         = 'Rot';
$lang['okbutton']              = 'Legg til ny side';
$lang['nooption']              = 'Du har ikke tilgang til å legge til sider';
