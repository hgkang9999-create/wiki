<?php
/*
 * polish language file
 */
$lang['namespaceRoot'] = "Główny";
$lang['okbutton']      = "Dodaj stronę";
$lang['nooption']      = "Nie masz uprawnień aby dodać nową stronę";
//Setup VIM: ex: et ts=2 enc=utf-8 :
