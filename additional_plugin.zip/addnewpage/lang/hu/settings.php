<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Fekete Ádám Zsolt <fadam@egbcsoport.hu>
 */
$lang['addpage_exclude']       = 'Elrejtett névterek (pontosvesszővel elválasztva)';
$lang['addpage_showroot']      = 'Kiindulónévtér mutatása';
$lang['addpage_hide']          = 'A {{NEWPAGE>[ns]}} szintaxis használatakor: Névtérválasztó lista elrejtése (ha nincs bejelölve: mutatja az alnévtereket)';
$lang['addpage_hideACL']       = 'A {{NEWPAGE}} elrejtése ha a felhasználónak nincs jogosultsága oldal létrehozásához (ha nincs bejelölve, egy üzenet fog megjelenni)';
