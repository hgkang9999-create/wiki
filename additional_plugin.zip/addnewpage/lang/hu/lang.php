<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Fekete Ádám Zsolt <fadam@egbcsoport.hu>
 */
$lang['namespaceRoot']         = 'Kiindulónévtér';
$lang['okbutton']              = 'Oldal hozzáadása';
$lang['nooption']              = 'Nincs jogosultságod oldal létrehozásához';
