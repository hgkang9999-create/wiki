<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Daniele Savasta <danielesavasta@tiscali.it>
 * @author Mirko <malisan.mirko@gmail.com>
 */
$lang['namespaceRoot']         = 'Root';
$lang['okbutton']              = 'Aggiungi Pagina';
$lang['nooption']              = 'Non sei autorizzato ad aggiungere nuove pagine';
