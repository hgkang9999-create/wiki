<?php
/*USE : UTF8*/

/*
 * Japanese language file
 */
$lang['addpage_exclude']  = "除外する名前空間（; 区切り）";
$lang['addpage_showroot'] = "ルート名前空間を表示";
$lang['addpage_hide']     = "{{NEWPAGE>[ns]}} 構文使用時： 名前空間選択リストを表示しない（チェックなし： 下位名前空間のみを表示）";
$lang['addpage_hideACL']  = "ページ追加の権限を持たないユーザーに対しては {{NEWPAGE}} を表示しない（チェックなしの場合にはメッセージを表示）";
