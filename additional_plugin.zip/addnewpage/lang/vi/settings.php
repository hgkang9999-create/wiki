<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * USE : UTF8
 * Vietnamese language file
 *
 * @author Thien Hau <thienhausoftware@gmail.com>
 */
$lang['addpage_exclude']       = 'Trừ không gian tên (ngăn cách bằng dấu ;)';
$lang['addpage_showroot']      = 'Hiển thị không gian tên gốc';
$lang['addpage_hide']          = 'Khi bạn chọn syntax {{NEWPAGE>[ns]}}: Ẩn khả năng lựa chọn không gian tên (không chọn: chỉ hiển thị không gian tên con)';
$lang['addpage_hideACL']       = 'Ẩn {{NEWPAGE}} nếu người dùng không được phép tạo trang mới (hiển thị tin nhắn nếu không chọn)';
