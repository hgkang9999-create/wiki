<?php
/*USE : UTF8*/

/*
 * English language file
 */
$lang['addpage_exclude']  = "Excluded namespaces (separated with ;)";
$lang['addpage_showroot'] = "Show root namespace";
$lang['addpage_hide']     = "When you use {{NEWPAGE>[ns]}} syntax: Hide namespace selection (unchecked: show only subnamespaces)";
$lang['addpage_hideACL']  = "Hide {{NEWPAGE}} if user does not have rights to add pages (show message if unchecked)";
$lang['addpage_autopage'] = "Don't show the input box, the preconfigured namespace is treated as a full page ID. (makes sense with date placeholders)";
