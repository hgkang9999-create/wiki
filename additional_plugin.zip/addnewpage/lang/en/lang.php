<?php
/*
 * English language file
 */
$lang['namespaceRoot'] = "Root";
$lang['name']          = "Page name";
$lang['okbutton']      = "Add page";
$lang['nooption']      = "You are not allowed to add pages";
//Setup VIM: ex: et ts=2 enc=utf-8 :
