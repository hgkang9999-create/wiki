<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Eduardo Mozart de Oliveira <eduardomozart182@gmail.com>
 * @author Samory Pereira Santos <samory.santos@gmail.com>
 */
$lang['namespaceRoot']         = 'Raiz';
$lang['name']                  = 'Nome da página';
$lang['okbutton']              = 'Adicionar página';
$lang['nooption']              = 'Você não tem permissão para adicionar páginas';
