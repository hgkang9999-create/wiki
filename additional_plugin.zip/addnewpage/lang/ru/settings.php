<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author serg <sergey_art82@inbox.ru>
 * @author Aleksandr Selivanov <alexgearbox@yandex.ru>
 */
$lang['addpage_exclude']       = 'Исключаемые пространства имен (разделитель — точка с запятой)';
$lang['addpage_showroot']      = 'Показать корневое пространство имён';
$lang['addpage_hide']          = 'При использовании синтаксиса {{NEWPAGE>[ns]}} скрывать выбор пространства имён. (Если флажок снят, будут показываться только подпространства имён.)';
$lang['addpage_hideACL']       = 'Скрыть {{NEWPAGE}}, если пользователь не имеет прав на добавление страниц. (Если флажок снят, будет отображаться сообщение.)';
