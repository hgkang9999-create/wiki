<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Aleksandr Selivanov <alexgearbox@yandex.ru>
 */
$lang['namespaceRoot']         = 'Корневой уровень';
$lang['name']                  = 'Имя страницы';
$lang['okbutton']              = 'Добавить страницу';
$lang['nooption']              = 'Вы не можете добавлять страницы';
