<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author analogroboter <ropely@gmx.net>
 * @author Joerg <scooter22@gmx.de>
 * @author Michael <michael@krmr.org>
 */
$lang['namespaceRoot']         = 'Wurzel';
$lang['name']                  = 'Seitenname';
$lang['okbutton']              = 'Seite hinzufügen';
$lang['nooption']              = 'Du besitzt nicht die Benutzerrechte, um Seiten hinzuzufügen.';
