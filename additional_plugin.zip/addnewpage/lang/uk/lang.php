<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * Ukrainian language file
 *
 * @author Олексій <alexey.furashev@gmail.com>
 */
$lang['namespaceRoot']         = 'Кореневий простір імен';
$lang['okbutton']              = 'Додати сторінку';
$lang['nooption']              = 'Ви не можете додавати сторінки';
