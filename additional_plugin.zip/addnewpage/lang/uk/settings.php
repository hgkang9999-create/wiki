<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * USE : UTF8
 * Ukrainian language file
 *
 */
$lang['addpage_exclude']       = 'Виключені простори імен (розділені ;)';
$lang['addpage_showroot']      = 'Відображати кореневий простір імен';
$lang['addpage_hide']          = 'При застосуванні {{NEWPAGE>[ns]}} сховати вибір простору імен (якщо вибрано цей пункт  - відображати тільки підпростір імен)';
$lang['addpage_hideACL']       = 'Сховати {{NEWPAGE}}, якщо користувач не має прав додавати сторінки (відображати повідомлення, якщо цей пункт не вибрано)';
