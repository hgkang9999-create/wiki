<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Hugo Smet <hugo.smet@scarlet.be>
 */
$lang['namespaceRoot']         = 'Root';
$lang['okbutton']              = 'Pagina toevoegen';
$lang['nooption']              = 'U heeft geen rechten om pagina\'s toe te voegen';
