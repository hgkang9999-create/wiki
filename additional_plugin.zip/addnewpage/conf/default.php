<?php
$conf['addpage_exclude']  = "wiki;playground";
$conf['addpage_showroot'] = 1;
$conf['addpage_hide']     = 1;
$conf['addpage_hideACL']  = 0;
$conf['addpage_autopage'] = 0;

