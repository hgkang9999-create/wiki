/* DOKUWIKI:include_once lib/handsontable.full.js */

/* DOKUWIKI:include script/contextmenu.js */
/* DOKUWIKI:include script/editor.js */
/* DOKUWIKI:include script/newtable.js */
/* DOKUWIKI:include script/editbutton.js */
