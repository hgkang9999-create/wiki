<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Yuriy Skalko <yuriy.skalko@gmail.com>
 */
$lang['default colwidth']      = 'Ширина столбцов таблицы. Оставьте пустым для задания ширины по содержимому';
