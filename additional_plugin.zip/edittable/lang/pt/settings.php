<?php

/**
 * @license    GPL 2 (https://www.gnu.org/licenses/gpl.html)
 *
 * @author João Frade | 100Nome <100nome.portugal@gmail.com>
 */
$lang['default colwidth']      = 'Largura das colunas na tabela. Deixar vazio para ajustar largura ao conteúdo';
