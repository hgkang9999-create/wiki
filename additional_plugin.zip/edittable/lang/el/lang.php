<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Aikaterini Katapodi <extragold1234@hotmail.com>
 */
$lang['secedit_name']          = 'Πίνακας';
$lang['add_table']             = 'Εισάγετε νέο πίνακα';
$lang['js']['toggle_header']   = 'Ελέγξετε τον τίτλο';
$lang['js']['align_left']      = 'Ευθυγραμμισμένο κελί αριστερά';
$lang['js']['align_center']    = 'Κεντρικό κελί';
$lang['js']['align_right']     = 'Ευθυγράμμιση κελιού δεξιά';
$lang['js']['confirmdeleterow'] = 'Θέλετε να διαγράψετε την σειρά?';
$lang['js']['confirmdeletecol'] = 'Θέλετε να σβήσετε την στήλη?';
