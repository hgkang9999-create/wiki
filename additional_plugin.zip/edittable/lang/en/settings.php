<?php

$lang['default colwidth'] = 'Width of table columns. Leave empty to base width on content';
