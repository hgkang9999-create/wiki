<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Karstein Kvistad <spamme.post@gmail.com>
 */
$lang['default colwidth']      = 'Bredden til tabellkolonner. La stå tom for endre automatisk til innhold';
