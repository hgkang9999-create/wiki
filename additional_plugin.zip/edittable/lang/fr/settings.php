<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Schplurtz le Déboulonné <Schplurtz@laposte.net>
 */
$lang['default colwidth']      = 'Largeur des colonnes. Laisser vider pour une adaptation automatique.';
