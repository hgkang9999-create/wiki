<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Felix Müller-Donath <j.felix@mueller-donath.de>
 */
$lang['default colwidth']      = 'Breite der Tabellenspalten. Ohne Angabe wird die Breite anhand des Inhaltes ermittelt.';
