<?php

/**
 * @license    GPL 2 (https://www.gnu.org/licenses/gpl.html)
 *
 * @author Alex Souza <contato@remotoservicos.com.br>
 */
$lang['default colwidth']      = 'Largura das colunas. Deixe vazio para ajustar ao conteúdo';
