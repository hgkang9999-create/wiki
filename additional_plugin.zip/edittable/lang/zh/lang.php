<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author kuma <kuma000@qq.com>
 */
$lang['secedit_name']          = '表';
$lang['add_table']             = '插入新表';
$lang['js']['toggle_header']   = '切换页眉状态';
$lang['js']['align_left']      = '左对齐单元格';
$lang['js']['align_center']    = '居中对齐单元格';
$lang['js']['align_right']     = '右对齐单元格';
$lang['js']['confirmdeleterow'] = '真的删除行吗？';
$lang['js']['confirmdeletecol'] = '真的删除列吗？';
$lang['js']['row_above']       = '上面添加一行';
$lang['js']['remove_row']      = '删除行';
$lang['js']['row_below']       = '下面添加一行';
$lang['js']['col_left']        = '在左侧添加列';
$lang['js']['remove_col']      = '删除列';
$lang['js']['col_right']       = '在右侧添加列';
$lang['js']['merge_cells']     = '合并单元格';
$lang['js']['unmerge_cells']   = '拆分单元格';
