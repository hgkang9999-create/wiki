<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author kuma <kuma000@qq.com>
 */
$lang['default colwidth']      = '表列宽度。在内容上留空';
