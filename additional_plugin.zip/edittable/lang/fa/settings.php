<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Nima Hamidian <nima.hamidian@gmail.com>
 */
$lang['default colwidth']      = 'عرض ستونهای جدول. اگر خالی گذاشته شود عرض مبتنی بر محتوا خواهد بود';
