<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Bartek S <sadupl@gmail.com>
 */
$lang['default colwidth']      = 'Szerokość kolumn tabeli. Pozostaw puste do szerokości bazowej.';
