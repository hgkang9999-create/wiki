<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Klap-in <klapinklapin@gmail.com>
 */
$lang['default colwidth']      = 'Breedte van de kolommen van de tabel. Leeg laten om de breedte op de inhoud te baseren';
