<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author 5d <chk@renshuu.tw>
 */
$lang['default colwidth']      = '表格列的寬度，若不填即視內容自動調整寬度';
