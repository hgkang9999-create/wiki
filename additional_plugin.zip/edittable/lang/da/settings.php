<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Jacob Palm <jacobpalmdk@icloud.com>
 */
$lang['default colwidth']      = 'Bredde af tabelkolonner. Efterlad blank for at tilpasse til indhold';
