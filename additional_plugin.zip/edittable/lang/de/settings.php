<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Joerg Hippe <scooter22@gmx.de>
 */
$lang['default colwidth']      = 'Breite der Tabellenspalten. Ohne Angabe wird die Breite anhand des Inhaltes ermittelt.';
