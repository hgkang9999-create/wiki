<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Thien Hau <thienhau.9a14@gmail.com>
 */
$lang['default colwidth']      = 'Chiều rộng của cột trong bảng. Để trống để định chiều rộng dựa trên nội dung';
