<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Tor Härnqvist <tor@harnqvist.se>
 */
$lang['default colwidth']      = 'Bredd på tabellkolumner. Lämna tomt för att justera efter innehållet';
