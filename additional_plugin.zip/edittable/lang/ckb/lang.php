<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author qezwan <qezwan@gmail.com>
 */
$lang['secedit_name']          = 'خشتە

';
$lang['add_table']             = 'خشتەیەکی نوێ بکەنێو	

';
$lang['js']['toggle_header']   = 'گۆڕینی رەوشی سەرپەڕە

';
$lang['js']['align_left']      = 'خانەی لاچەن بۆلای چەپ
';
$lang['js']['align_center']    = 'خانەی ناوەڕاست
';
$lang['js']['align_right']     = 'خانەی لاچەنکردن بۆ لای ڕاست
';
$lang['js']['confirmdeleterow'] = 'بەڕاستی ڕیز ەکە دەسڕیتەوە؟
';
$lang['js']['confirmdeletecol'] = 'بەڕاستی ستوون بسڕەوە؟
';
$lang['js']['row_above']       = 'ڕیز زیاد بکە لەسەرەوە
';
$lang['js']['remove_row']      = 'لابردنی ڕیز
';
$lang['js']['row_below']       = 'ڕیز زیاد بکە لە خوارەوە
';
$lang['js']['col_left']        = 'زیادکردنی ئەستوون لە لای چەپ
';
$lang['js']['remove_col']      = 'لابردنی ستوون
';
$lang['js']['col_right']       = 'زیادکردنی ئەستوون لە لای ڕاست
';
$lang['js']['merge_cells']     = 'خانەکان یەکبخە
';
$lang['js']['unmerge_cells']   = 'خانەکان بەش بکە
';
