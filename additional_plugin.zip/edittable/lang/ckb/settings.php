<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author qezwan <qezwan@gmail.com>
 */
$lang['default colwidth']      = 'پانی ستوونەکانی خشتە. بە بەتاڵی بهێڵەوە بۆ بناغەی پانی لەسەر ناوەڕۆک
';
