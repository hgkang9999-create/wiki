<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Hideaki SAWADA <chuno@live.jp>
 */
$lang['default colwidth']      = 'テーブルの列の幅。コンテンツの幅を基準にする場合、空のままにする';
