<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Martin Růžička <martinr@post.cz>
 * @author Vojta Olsan <olsh0@seznam.cz>
 */
$lang['default colwidth']      = 'Šířka sloupců tabulky. Nechte prázdné pro šířku podle obsahu.';
