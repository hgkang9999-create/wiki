<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Domingo Redal <docxml@gmail.com>
 */
$lang['default colwidth']      = 'Ancho de las columnas de la tabla. Dejar vacío para ajustar el ancho según en el contenido';
