<?php

$meta['default colwidth'] = array('numericopt', '_min' => 50);
