<?php

$conf['default colwidth'] = '';
