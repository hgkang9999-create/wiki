<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Nicolas Friedli <nicolas@theologique.ch>
 */
$lang['colors']                = 'Couleurs de police, classées de faible à forte';
$lang['background-colors']     = 'Couleurs de fond, classées de faible à forte';
