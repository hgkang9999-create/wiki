<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author İlker R. Kapaç <irifat@gmail.com>
 */
$lang['colors']                = 'Yazı rengi. (Nokta sayıısına göre sıralanmışlardır.) ';
$lang['background-colors']     = 'Arkaplan renkleri. (Virgül sayıısına göre sıralanmışlardır.) ';
