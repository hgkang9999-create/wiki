<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Bartek S <sadupl@gmail.com>
 */
$lang['colors']                = 'Kolor czcionki, kolejność od niskiej do wysokiej';
$lang['background-colors']     = 'Kolor tła, kolejność od niskiej do wysokiej';
