<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Myeongjin <aranet100@gmail.com>
 */
$lang['colors']                = '글꼴 색, 낮은 순서에서 높은 순서로';
$lang['background-colors']     = '배경 색, 낮은 순서에서 높은 순서로';
