<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Alexandre Belchior <alexbelchior@gmail.com>
 */
$lang['colors']                = 'Cores das fontes, ordenadas de baixo para cima';
$lang['background-colors']     = 'Cores de fundo, ordenadas de baixo para cima';
