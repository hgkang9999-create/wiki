<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Matthias Schulte <dokuwiki@lupo49.de>
 */
$lang['colors']                = 'Schriftfarben, aufsteigend sortiert';
$lang['background-colors']     = 'Hintergrundfarben, aufsteigend sortiert';
