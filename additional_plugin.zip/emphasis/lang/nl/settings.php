<?php

$lang['colors']            = 'Letterkleuren, gesorteerd van laag naar hoog';
$lang['background-colors'] = 'Achtergrondkleuren, gesorteerd van laag naar hoog';
