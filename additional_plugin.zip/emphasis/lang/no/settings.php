<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Arne Hanssen <arne.hanssen@getmail.no>
 */
$lang['colors']                = 'Tekstfarge, sortert fra lav til høy';
$lang['background-colors']     = 'Bakgrunnsfarge, sortert fra lav til høy';
