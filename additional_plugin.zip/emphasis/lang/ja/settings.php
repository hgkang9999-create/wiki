<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Hideaki SAWADA <chuno@live.jp>
 */
$lang['colors']                = '小〜大順の文字色';
$lang['background-colors']     = '小〜大順の背景色';
