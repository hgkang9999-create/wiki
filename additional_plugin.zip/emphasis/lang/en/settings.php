<?php

$lang['colors']            = 'Font colors, ordered from low to high';
$lang['background-colors'] = 'Background colors, ordered from low to high';
