<?php

$conf['colors']            = '#009700, #ffb200, #ff0033';
$conf['background-colors'] = '#009700, #ffea00, #ff0033';