<?php

$meta['colors']            = array('string');
$meta['background-colors'] = array('string');

