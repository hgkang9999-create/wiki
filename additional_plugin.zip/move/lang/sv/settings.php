<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Tor Härnqvist <tor@harnqvist.se>
 */
$lang['allowrename']           = 'Tillåt namnbyte på sidor i dessa grupper och från användare (kommaseparerat).';
$lang['pagetools_integration'] = 'Lägg till namnändringsknapp till sidverktygen';
