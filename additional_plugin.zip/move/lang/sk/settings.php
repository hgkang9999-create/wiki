<?php

/*
 * @author Viktor Kristian <vkristian@gmail.com>
 */

$lang['allowrename']           = 'Povoliť premenovávanie stránok týmto používateľom a skupinám (oddelených čiarkou).';
$lang['minor']                 = 'Označiť úpravu odkazov ako drobnú zmenu? Drobné zmeny nebudú viditelné v RSS feedoch a v e-mailoch informujcich o zmenách.';
$lang['autoskip']              = 'Zapnúť východzie automatické preskakovanie chýb pri presune menného priestoru.';
$lang['autorewrite']           = 'Zapnúť východzie automatické prepisovanie odkazov po presune menného priestoru.';
$lang['pagetools_integration'] = 'Pridať tlačidlo na premenovanie do nástrojov stránky';
