<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Thien Hau <thienhausoftware@gmail.com>
 */
$lang['allowrename']           = 'Cho phép đổi tên các trang thành các nhóm và thành viên này (được phân tách bằng dấu phẩy).';
$lang['minor']                 = 'Đánh dấu việc điều chỉnh liên kết là nhỏ? Những thay đổi nhỏ sẽ không được liệt kê trong nguồn cấp dữ liệu RSS và thư đăng ký.';
$lang['autoskip']              = 'Cho phép tự động bỏ qua các lỗi trong di chuyển không gian tên theo mặc định.';
$lang['autorewrite']           = 'Cho phép tự động viết lại liên kết sau khi di chuyển không gian tên theo mặc định.';
$lang['pagetools_integration'] = 'Thêm nút đổi tên vào Công cụ trang';
