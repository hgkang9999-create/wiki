<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author NawanP <saya@nawan.my.id>
 */
$lang['allowrename']           = 'Izinkan pengguna dan grup ini untuk mengubah nama halaman (pisahkan dengan koma).';
$lang['minor']                 = 'Tandai penyesuaian pranala sebagai perubahan kecil? Perubahan kecil tidak akan terlihat di feed RSS dan milis.';
$lang['autoskip']              = 'Aktifkan lewati otomatis galat saat memindahkan ruangnama secara default.';
$lang['autorewrite']           = 'Aktifkan pengubahan pranala secara default saat memindahkan ruangnama.';
$lang['pagetools_integration'] = 'Tambahkan tombol ubah nama ke pagetools';
