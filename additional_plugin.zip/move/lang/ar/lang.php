<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author aljailane <shop@souqye.com>
 */
$lang['menu']                  = 'نقل الصفحات ومساحات الأسماء';
$lang['inprogress']            = '(التحرك معلق)';
$lang['treelink']              = 'بدلاً من هذا النموذج البسيط ، يمكنك إدارة إعادة الهيكلة المعقدة لموقع wiki الخاص بك باستخدام <a href="%s"> مدير النقل المستند إلى الشجرة </a>.	';
