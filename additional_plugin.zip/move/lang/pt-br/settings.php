<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Daniel Dias Rodrigues <danieldiasr@gmail.com>
 */
$lang['allowrename']           = 'Permitir renomeação de páginas para esses grupos e usuários (separados por vírgula).';
$lang['minor']                 = 'Marcar ajustes de link como menores? Alterações menores não serão listadas em feeds RSS e listas de e-mails.';
$lang['autoskip']              = 'Ativa o salto automático de erros em movimentações de domínio por padrão.';
$lang['autorewrite']           = 'Habilita a regravação automática do link após a movimentação do domínio por padrão.';
$lang['pagetools_integration'] = 'Adicionar botão de renomeação às ferramentas de página';
