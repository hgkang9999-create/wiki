<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Domingo Redal <docxml@gmail.com>
 */
$lang['allowrename']           = 'Permitir el cambio de nombre de páginas a estos grupos y usuarios (separados por comas).';
$lang['minor']                 = '¿Marcar los ajustes de enlace como cambios menores? Los cambios menores no se incluirán en los feeds RSS ni en los correos de suscripción.';
$lang['autoskip']              = 'Habilitar de forma predeterminada el salto automático de errores en las operaciones de mover el espacio de nombres.';
$lang['autorewrite']           = 'Habilitar de forma predeterminada la reescritura automática de enlaces después de mover el espacio de nombres.';
$lang['pagetools_integration'] = 'Añadir botón de cambio de nombre a las herramientas de página';
