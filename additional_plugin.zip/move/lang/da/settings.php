<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Jacob Palm <jacobpalmdk@icloud.com>
 */
$lang['allowrename']           = 'Tillad disse grupper og brugere at omdøbe sider (adskil med komma).';
$lang['minor']                 = 'Markér tilretning af links som mindre rettelser? Mindre rettelser optræder ikke i RSS-feeds elller mails.';
$lang['autoskip']              = 'Slå overspring af fejl under flytning af navnerum til som standard';
$lang['autorewrite']           = 'Slå automatisk tilrettelse af links efter flytning af navnerum til som standard';
$lang['pagetools_integration'] = 'Tilføj omdøbningsknap til sideværktøjer';
