<?php
/**
 * Dutch language file for settings.
 *
 * @author Mark C. Prins <mprins@users.sf.net>
 */
$lang['allow_in_comments'] = 'Of de filelist syntax toegestaan is voor gebruik in commentaar.';
$lang['defaults'] = 'Default options. Gebruik dezelfde syntax als de inline configuratie.';
$lang['extensions'] = 'Komma-gescheiden lijst van toegestane bestandsextensies voor de lijst.';
