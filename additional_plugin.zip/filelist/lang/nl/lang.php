<?php
/*
 * additional language strings used by plugin
 *
 * dutch version
 *
 * @author Mark C. Prins <mprins@users.sf.net>
 */
$lang['filename'] = 'Bestandsnaam';
$lang['filesize'] = 'Bestandsgrootte';
$lang['lastmodified'] = 'Laatst gewijzigd';
$lang['error_nomatch'] = 'Niets gevonden';
$lang['error_outsidejail'] = 'Toegang geweigerd';
