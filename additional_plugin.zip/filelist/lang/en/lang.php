<?php
/*
 * additional language strings used by plugin
 *
 * english version
 *
 * @author Gina Haeussge <osd@foosel.net>
 */

$lang['filename'] = 'Filename';
$lang['filesize'] = 'Filesize';
$lang['lastmodified'] = 'Last modified';
$lang['error_nomatch'] = 'No match';
$lang['error_outsidejail'] = 'Access denied';
