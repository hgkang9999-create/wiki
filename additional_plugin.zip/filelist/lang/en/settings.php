<?php

$lang['allow_in_comments'] = 'Whether to allow the filelist syntax to be used in comments.';
$lang['defaults'] = 'Default options. Use the same syntax as in inline configuration';
$lang['extensions'] = 'Comma-separated list of allowed file extensions to list';
