<?php

$lang['allow_in_comments'] = 'Filelistsyntax in Kommentaren erlauben.';
