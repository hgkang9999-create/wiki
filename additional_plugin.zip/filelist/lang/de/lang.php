<?php
/*
 * additional language strings used by plugin
 *
 * german version
 *
 * @author Gina Haeussge <osd@foosel.net>
 */

$lang['filename'] = 'Dateiname';
$lang['filesize'] = 'Dateigröße';
$lang['lastmodified'] = 'Letzte Änderung';
$lang['error_nomatch'] = 'Keine Treffer';
$lang['error_outsidejail'] = 'Zugriff verweigert';
