<?php

/**
 * Metadata for configuration manager plugin
 * Additions for the filelist plugin
 *
 * @author Gina Haeussge <osd@foosel.net>
 */

$meta['paths'] = array('');
$meta['allow_in_comments'] = array('onoff');
$meta['defaults'] = array('string');
$meta['extensions'] = array('string');
