<?php

/**
 * Options for the filelist plugin
 */

$conf['paths'] = '';
$conf['allow_in_comments'] = 0;
$conf['defaults'] = '';
$conf['extensions'] = '';
