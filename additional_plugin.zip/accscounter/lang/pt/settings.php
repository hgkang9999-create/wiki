<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Paulo Schopf <pschopf@gmail.com>
 */
$lang['excludeMgAndSp_o_0']    = 'Contar ambos';
$lang['excludeMgAndSp_o_sp']   = 'Não contar superusuários';
$lang['excludeMgAndSp_o_mg']   = 'Não contar gerenciadores (incluindo superusuários)';
$lang['saveLog_o_0']           = 'Não salvar';
$lang['saveLog_o_ppage']       = 'Salvar (Não criar arquivos para cada data)';
$lang['saveLog_o_pdate']       = 'Salvar (Criar arquivos para cada data)';
