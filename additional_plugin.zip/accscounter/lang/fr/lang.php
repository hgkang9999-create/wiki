<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Schplurtz le Déboulonné <Schplurtz@laposte.net>
 */
$lang['selectall']             = 'Tout cocher';
$lang['sofar']                 = 'Nb vues jusqu\'à maintenant';
$lang['lastdate']              = 'dernier accès le';
$lang['today']                 = 'Nb vues ce jour';
$lang['yest']                  = 'Nb vues hier';
$lang['ipadd']                 = 'Addresse IP du dernier visiteur';
$lang['delete']                = 'Supprimer le journal';
$lang['sfstried']              = 'L\'addresse IP %2$s d\'un spammeur à accédé %3$d fois à la page %1$s. Le système a déduit le nombre d\'accès du spammeur du nombre de vues total et du nombre de vues de ce jour.';
$lang['mngfaileddel']          = 'Erreur lors de la suppression de la page %s. Confirmez la permission d\'accéder aux fichiers du dossier où le système conserve les métafichiers. Si vous ne comprenez pas ce message, détruisez vous même les fichiers avec un outil comme un client FTP.';
$lang['mngdelfinish']          = 'Suppression du journal terminée';
