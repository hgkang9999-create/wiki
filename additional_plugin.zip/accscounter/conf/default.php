<?php

$conf['timezone'] = '';
$conf['excludeMgAndSp'] = '0';
$conf['exclusionList'] = '';
$conf['usrExclusion'] = '';
$conf['cntrExclusion'] = '';
$conf['cntrInclusion'] = '';
$conf['reverseLookupFailed'] = '0';
$conf['reverseLookupException'] = '';
$conf['reverseLookupCntrException'] = '';
$conf['sfsExFreq'] = '0';
$conf['sfsExConf'] = '0';
$conf['saveLog'] = '0';
$conf['ipgdpr'] = '1';